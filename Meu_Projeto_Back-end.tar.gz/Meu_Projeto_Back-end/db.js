async function connect() {
    // Verifica se já existe uma conexão ativa para evitar múltiplas conexões
    if (globalThis.connection && globalThis.connection.state !== "disconnected")
        return globalThis.connection;


    // "promise" com um 's' e protocolo "mysql://" correto
    const mysql =require ("mysql2/promise") 
        const connection = await mysql.createConnection
        ("mysql://root:escola@localhost:3306/ExMyNode",);
        
        console.log("Conectou no MySQL!");
        global.connection = connection;
        return connection;
    } 

//async function selectProdutos() {
   // const conn = await connect();
    //return await conn.query("SELECT * FROM produtos");
//}

async function updateProdutos(codigo_produto, produto) {
    const conn = await connect();
    const sql = "UPDATE produtos SET descricao=?, quantidade=? WHERE codProduto=?";
    const values = [produto.descricao, produto.quantidade, codigo_produto];
    await conn.query (sql, values);

}

module.exports = {updateProdutos};