CREATE SCHEMA ExMyNode;
USE ExMyNode;
create table produtos(
   codProduto int auto_increment primary key,
   descricao varchar(80) not null,
   quantidade int
);
insert into produtos(descricao, quantidade) values ('mesa', 5);
insert into produtos(descricao, quantidade) values ('cadeira', 10);
insert into produtos(descricao, quantidade) values ('mouse', 8);

CREATE TABLE clientes (
    codCliente INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(80) NOT NULL,
    sexo VARCHAR(15) NOT NULL
);

INSERT INTO clientes (nome, sexo) VALUES ('Fernando', 'Masculino');
INSERT INTO clientes (nome, sexo) VALUES ('Gerson', 'Não Binário');
INSERT INTO clientes (nome, sexo) VALUES ('Paulão', 'Macho');

SELECT * FROM produtos;


