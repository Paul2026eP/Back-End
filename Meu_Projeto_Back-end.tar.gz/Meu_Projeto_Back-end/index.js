//console.log('JS para back');

//(async () => {
    // 1. Importa o módulo do banco de dados
  //  const db = require("./db");
    //console.log("começou!");
    
    //console.log("SELECT * FROM PRODUTO");

    //console.log("SELECT * FROM CLIENTES");

        // 2. Chama a função e armazena o resultado na variável produto
        //const produto = await db.selectProdutos();
        
        // 3. Exibe o resultado de forma visual (tabela)
        //console.log(produto);

  /*
(async () => {
  const db = require("./db");
  console.log("Começou!");

  console.log("SELECT * FROM CLIENTES");
  const prod = await db.selectProdutos();
  console.log(prod);
})();
*/


(async () => {
  const db = require("./db");
  console.log("Começou!");
  
  console.log("Exemplo de Update no MySQL pelo Back-end"); // 2º
  const result = await db.updateProdutos(2,{
  descricao: "Cadeira Giratória",
  quantidade: 12,
  });
  
  console.log(result);
  
})();// Fecha corretamente a função assíncrona

