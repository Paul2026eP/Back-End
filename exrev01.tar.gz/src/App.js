import './App.css';
// A pasta começa com 'C' maiúsculo conforme seu link
import Lista from './Components/Lista'; 

function App() {
  return (
    <div className="App">
      <Lista />
    </div>
  );
}

export default App;
