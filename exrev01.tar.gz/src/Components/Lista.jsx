import React from 'react';

const Lista = () => {
  // Criando a lista de freeworks
  const freeworks = [
    "Downloads",
    "Estudos",
    "Pesquisas",
    "Tutoriais",
    "Videos"
  ];

  return (
    <div className="lista-container" style={{ textAlign: 'center', 
    padding: '20px' }}>
      <h2>Meu Colab</h2>
      
      <div className="Imagem">
        <img 
          src="/imagem.jpg" 
          className="base" 
          width="170" 
          height="179" 
          alt="Descrição da imagem" 
          style={{ marginTop: '10px', borderRadius: '8px' }}
        />
      </div>

      {/* Renderizando a lista de freeworks */}
      <div style={{ marginTop: '20px' }}>
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {freeworks.map((freeworks, index) => (
            <li key={index} style={{ padding: '8px', fontSize: 
            '1.2rem', color: '#333' }}>
              {freeworks}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default Lista;
