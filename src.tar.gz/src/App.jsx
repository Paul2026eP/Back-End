//parte da importação
import logo from './logo.svg';
import './App.css';

//parte dos componentes; somente pode usar um objeto Pai.
function App() {
  const name = "Paulo"
  const newName = name.toUpperCase ()
  const url = "https://corhexa.com/png/600x400/2s4fc2";
  function sum(a, b) {
    return a + b
  }
  return (
    <div className="App">
      <h1>Ola REACT</h1>    
      <p> Esse é meu primeiro APP</p>
      <p>Olá, {newName}</p>
      <p> soma: {sum(1, 2)}</p>
      <img src = {url} alt="Minha Imagem"/>
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}

export default App;
