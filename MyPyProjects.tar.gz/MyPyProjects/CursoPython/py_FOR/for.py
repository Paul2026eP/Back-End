

pessoas = {'Pedro', 'Maria', 'Jaime', 'Joana'}
for pes in pessoas:
    print ('Bem-vindo(a)' + pes + '!')