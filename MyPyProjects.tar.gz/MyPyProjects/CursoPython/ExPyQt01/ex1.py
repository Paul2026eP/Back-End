import sys
from PyQt6.QtWidgets import QApplication, QWidget, QPushButton, QLabel
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QCursor


app = QApplication
janela = QWidget
janela.resize(800, 600)
janela.setWindowTitle('Primeira Janela')
btn = QPushButton('Botao 1', janela)
btn.setGeometry(100, 100, 150, 80)

btn.setStyleSheet("""
QPushButton{
background-color: #007807; /* azul mais bonito
color: white;
border: none;
padding: apx 16px;
border-radius: 4px;
}

QPushButton: hover{
    background-color: #106EBE;
                   }

QPushButton:pressed {
    background-color: #005A9E
                   }
                
label = QLabel("Texto Qualquer", janela)